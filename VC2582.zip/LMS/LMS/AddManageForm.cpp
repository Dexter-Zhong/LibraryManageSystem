#include "stdafx.h"
#include "AddManageForm.h"

