#include "stdafx.h"
#include "MessageForm.h"

