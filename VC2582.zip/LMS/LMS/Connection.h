#pragma once
using namespace System;

namespace LMS {
	ref class Connection
	{
	public:Connection(){};
	public:static String^strConn;

	};
}